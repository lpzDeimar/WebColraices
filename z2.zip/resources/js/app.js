import React from 'react';
import reactDOM from 'react-dom';
import { App } from './routes/App';

reactDOM.render(<App />, document.getElementById('app'));















