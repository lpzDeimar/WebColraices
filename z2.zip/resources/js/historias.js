export default {
    historys: [
        {
            'id': '1',
            'img':'./img/history/bibiananaranjo.webp',
            'name': 'Bibiana Naranjo',
            'history': '“El valor de una empresa como Colraices es el acompañamiento, la eficiencia y la tranquilidad que transmiten para ayudarte a conseguir lo que deseas, con una gran calidad humana”.'
        },
        {
            'id': '2',
            'img':'./img/history/anacristina.webp',
            'name': 'Ana Cristina',
            'history': '“Me pareció muy bueno el servicio, fue rápido, fue muy buena experiencia. Colraices una solución para todos nosotros porque nos facilitan la forma para comprar la casa”. '
        }
    ],
};
