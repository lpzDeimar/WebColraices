import React, { useEffect } from 'react'
import { Banner } from '../components/credito/Banner'
import { Pasos } from '../components/credito/Pasos'
import { Bancos } from '../components/credito/Bancos'
import { Simulador } from '../components/credito/Simulador'
import { Soluciones } from '../components/Soluciones'


export const Credito = () => {

    useEffect(() => {
        scrollTo(0, 0);
    }, [])

    return (
        <div>
            <Banner />
            <Pasos />
            <Bancos />
            <Simulador />
            <Soluciones />
        </div>
    )
}
