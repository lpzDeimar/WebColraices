import React from 'react'

export const Portal = () => {
    return (
        <div>
            <h1>Portal</h1>
        </div>
    )
}
