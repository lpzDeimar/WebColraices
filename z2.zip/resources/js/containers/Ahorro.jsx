import React, { useEffect } from 'react'
import { Banner } from '../components/ahorro/Banner'
import { Inversion } from '../components/ahorro/Inversion'
import { Riqueza } from '../components/ahorro/Riqueza'
import { Remesa } from '../components/ahorro/Remesa'
import { Blogmin } from '../components/Blogmin'
import { Finanzas } from '../components/ahorro/Finanzas'

export const Ahorro = () => {

    useEffect(() => {
        scrollTo(0, 0);
    }, [])

    return (
        <div>
            <Banner/>
            <Riqueza/>
            <Inversion/>
            <Remesa/>
            <Finanzas/>
            <Blogmin/>
        </div>
    )
}
