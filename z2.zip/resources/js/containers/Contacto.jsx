import React, { useEffect } from 'react';
import { Formulario } from '../components/contacto/Formulario';
import { Blogmin } from '../components/Blogmin';
import { Soluciones } from '../components/Soluciones';


export const Contacto = () => {
    useEffect(() => {
        scrollTo(0, 0);
    }, [])

  return (
    <>
        <Formulario />
        <Blogmin />
        <Soluciones />
    </>
  )
}
