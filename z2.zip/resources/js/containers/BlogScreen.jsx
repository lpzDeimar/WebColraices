import React, { useEffect } from 'react'
import { Banner } from '../components/blogscreen/Banner'
import { Blogs } from '../components/blogscreen/blogs'
import { Inde } from '../components/blogscreen/inde'
import { Videos } from '../components/blogscreen/Videos'

export const BlogScreen = () => {

    useEffect(() => {
        scrollTo(0, 0);
    }, [])

    return (
        <>
        <Banner/>
        <Inde/>
        <Blogs/>
        <Videos />
        </>
    )
}
