import React, { useEffect } from 'react'
import { Blogmin } from '../components/Blogmin'
import { Alcanze } from '../components/home/Alcanze'
import { Banner } from '../components/home/Banner'
import { Como } from '../components/home/Como'
import { Historys } from '../components/home/Historys'
import { Metas } from '../components/home/Metas'
import { Mision } from '../components/home/Mision'

export const Home = () => {

    useEffect(() => {
        scrollTo(0, 0);
    }, [])

    return (

        <div>
            <Banner />
            <Mision />
            <Alcanze />
            <Como />
            <Metas />
            <Historys />
            <Blogmin />
        </div>
    )
}
