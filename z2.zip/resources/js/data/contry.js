export const contrykey = [
    {
        'id': '1',
        'cod': 'CO',
        'contry': 'el exterior',
        'colex': '4.700.000',
        'oficine': 'Oficina principal Bogotá, Colombia',
        'location': 'Calle 100 # 13 - 41 Oficina: 102',
        'number': '(+57 1) 3288939',
        'anumber': '+573105653998'
    },
    {
        'id': '2',
        'cod': 'ES',
        'contry': 'España',
        'colex': '368.000',
        'oficine': 'Oficina principal Bogotá, Colombia',
        'location': 'Calle 100 # 13 - 41 Oficina: 102',
        'number': '(+34) 603 486 757',
        'anumber': '+34603486757'
    },
    {
        'id': '3',
        'cod': 'US',
        'contry': 'EEUU',
        'colex': '1.200.000​',
        'oficine': 'Oficina principal Bogotá, Colombia',
        'location': 'Calle 100 # 13 - 41 Oficina: 102',
        'number': '1 (908) 423 9896',
        'anumber': '19084239896'
    },
    {
        'id': '4',
        'cod': 'GB',
        'contry': 'Reino Unido',
        'colex': ' 1.322',
        'oficine': 'Oficina principal Bogotá, Colombia',
        'location': 'Calle 100 # 13 - 41 Oficina: 102',
        'number': '(+44) 074 7663 7603',
        'anumber': '+4407476637603'
    }
];
