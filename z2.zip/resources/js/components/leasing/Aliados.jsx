import React from 'react';

export const Aliados = () => {
    return (
        <section className='aliados-main'>
            <section className="aliados-container">
                <h3>Contamos con los mejores <span>bancos de Colombia</span></h3>
                <section className="aliados-aliados">
                    <img src="./img/entidades/davivienda.webp" alt="casa en colombia con davivienda" />
                    <img src="./img/entidades/bbva.webp" alt="casa en colombia con bbva" />
                    <img src="./img/entidades/bancolombia.webp" alt="casa en colombia con bancolombia" />
                    <img src="./img/entidades/girosyfinanzas.webp" alt="casa en colombia con giros y finanzas" />
                </section>
            </section>
            <section className="aliados-content">
                <div className="content-aliados-beneficios">
                    <h4>Beneficios</h4>
                    <hr />
                    <ul className="beneficios">
                        <li>Podrás adquirir o habitar una vivienda, realizando pagos mensuales y luego decidir si deseas comprarla.</li>
                        <li>El canon mensual es una inversión. Tú eres dueño del dinero que aportas cada mes.</li>
                        <li>Si compras el inmueble el desembolso de dinero que harás será menor, ya que los pagos mensuales aportados suman al valor inicial de la casa. </li>
                        <li>Cuando termines tus aportes al leasing habitacional, el inmueble te será transferido al ejercer la opción de compra.</li>
                        <li>Tasas de interés más bajas.</li>
                    </ul>
                </div>

                <div className="content-aliados-requisitos">
                    <h4><span>Requisitos</span></h4>
                    <hr />
                    <ul className="requisitos">
                        <li>Debes ser mayor de 18 años. </li>
                        <li>Ser persona natural</li>
                        <li>La cuota mensual no debe superar el 30% de tus ingresos.</li>
                        <li>Tener ingresos económicos o actividad laboral estable.</li>
                        <li>Tener un buen historial crediticio.</li>
                        <li>Los únicos autorizados para aprobar el inmueble, son los peritos y abogados del banco</li>
                    </ul>
                    <h5>Debes saber</h5>
                    <section className="debes-saber">
                        <div>
                            <span></span>
                            <p>No es un contrato de arrendamiento. Por esta razón, los gastos de impuesto predial o mantenimiento correrán por tu cuenta.</p>
                        </div>
                        <div>
                            <span></span>
                            <p>Financiación hasta del 80% del valor del inmueble.</p>
                        </div>
                        <div>
                            <span></span>
                            <p>Vivienda nueva o usada, VIS y No VIS.</p>
                        </div>
                        <div>
                            <span></span>
                            <p>Debes pagar los gastos de compra-venta.</p>
                        </div>
                    </section>

                </div>
            </section>
        </section>
    )
}
