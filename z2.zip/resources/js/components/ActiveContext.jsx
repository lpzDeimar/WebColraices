import { createContext } from "react";

export const ActiveContext = createContext(null);
